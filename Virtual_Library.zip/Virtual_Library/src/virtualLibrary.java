/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Cam Thomas
 */


public class virtualLibrary {
    final private List<libraryUserAccount> userAccounts;

    public virtualLibrary() {
        this.userAccounts = new ArrayList<>();
    }

    public void addUserAccount(libraryUserAccount userAccount) {
        userAccounts.add(userAccount);
    }

    public void displayUserAccounts() {
        System.out.println("User Accounts:");
        for (libraryUserAccount userAccount : userAccounts) {
            System.out.println(userAccount.getName() + " - Account Number: " + userAccount.getAccountNumber());
        }
    }
    
    // Additional methods for managing available books, checkouts, returns, etc.
}
